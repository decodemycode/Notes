/*jshint esversion: 6 */
var scripts = document.getElementsByTagName('script');
var lastScript = scripts[scripts.length - 1];
var scriptName = lastScript.src;
console.log("loading: " + scriptName.substring(scriptName.lastIndexOf('/') + 1));

//localStorage.clear();
// If User adds a Note - Add to Local Storage
// If User Deletes a Note - Deletes from Local Storage
let addBtn = document.getElementById("addBtn").addEventListener("click", addNote);

// window.onload = shownotes;

document.addEventListener("DOMContentLoaded", shownotes);




function addNote(e) {
    let addTxt = document.getElementById("addTxt")
    let notes = localStorage.getItem("notes");
    if (!notes) {
        notesobj = [];
    }
    else {
        notesobj = JSON.parse(notes);
    }
    notesobj.push(addTxt.value);
    localStorage.setItem('notes', JSON.stringify(notesobj));
    addTxt.value = "";
    console.log(notes);
    shownotes();
}


function shownotes() {

    let notes = localStorage.getItem("notes");
    if (!notes) {
        notesobj = [];
    }
    else {
        notesobj = JSON.parse(notes);
    }
    let html = "";

    notesobj.forEach(function (element, index) {
        html +=
            `<div class="noteCard my-2 mx-2 card" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title" style="margin-left: 3em;">Note: ${String(index + 1)}</h5>
                    <div  id = "${'Heart' + String(index + 1)}" onclick = "toggleClass1(this.id)" class="like-btn"></div>
                    <p class="card-text"><pre name="txt">${element}</pre></p>
                    <button id = "${index}" onclick = "deleteNote(this.id)" class="btn btn-primary">Delete Note</button>
                </div>
            </div>
            `;
    });

    let notesElm = document.getElementById("notes");

    if (notesobj.length != 0) {
        notesElm.innerHTML = html;
    }
    else {
        notesElm.innerHTML = "<b>No Notes here</b>"
    }
}

function deleteNote(index) {
    let notes = localStorage.getItem("notes");
    if (!notes) {
        notesobj = [];
    }
    else {
        notesobj = JSON.parse(notes);
    }

    notesobj.splice(index, 1);
    localStorage.setItem('notes', JSON.stringify(notesobj));

    shownotes();
}

let searchTxt = document.getElementById("searchTxt");

searchTxt.addEventListener("input", function () {
    inputval = searchTxt.value;
    notecards = document.querySelectorAll(".noteCard");
    //cardlist = document.querySelector(".card-text");

    Array.from(notecards).forEach(function (element) {
        let cardTxt = element.getElementsByTagName("pre")[0].innerText;
        if (cardTxt.toLowerCase().includes(inputval.toLowerCase())) {
            element.style.display = "block";
        }
        else {
            element.style.display = "none";
        }

    });



});

function toggleClass1(elm) {
    let heart = document.getElementById(elm);
    heart.classList.toggle("is-active");



}

